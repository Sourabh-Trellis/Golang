package main

import "fmt"

func main() {
	const PI = 3.14159

	fmt.Printf("Value of pi is %v.\n", PI)
}
