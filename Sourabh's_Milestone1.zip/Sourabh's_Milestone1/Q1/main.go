package main

import "fmt"

func main()  {
	var name string

	name = "John"

	fmt.Printf("Value of name is %v.\n",name)
}